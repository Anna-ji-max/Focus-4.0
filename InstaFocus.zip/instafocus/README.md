# InstaFocus

InstaFocus is an Android accessibility-overlay companion for Instagram. It is designed to keep the social parts of Instagram usable while removing the infinite-scroll surfaces:

- Home feed: posts below the Stories area are covered and touches are consumed.
- Reels tab: the full screen is covered. A left-edge right-swipe triggers Back so the user can leave the blocked screen.
- Home bottom navigation: only the Reels target is covered; Search, Messages and Profile remain usable.
- Search: the search field stays usable. When no query has been entered, the suggestion area is covered and a small motivational quote is shown. Entering a query exposes results.
- Stories and DMs: not covered, so Stories and content shared by friends through DMs can remain accessible. A Reel opened directly from a DM is treated as a shared viewer and is not blocked.
- Light/dark appearance follows the device UI mode.

## Setup

1. Install the generated APK.
2. Open InstaFocus.
3. Enable **Accessibility Service** for InstaFocus.
4. Allow **Display over other apps** if Android asks for it.
5. Open Instagram.

The service is scoped to `com.instagram.android`; it does not draw over unrelated apps.

## GitHub Actions

Workflow file: `.github/workflows/android.yml`

It builds the debug APK and publishes it as an Actions artifact.

## Important compatibility note

Instagram changes its accessibility labels and layout regularly. This project deliberately uses labels such as Home, Reels, Search and Messages plus geometry based on the current screen size. If Instagram changes those labels or radically changes its navigation, the detection constants in `InstaAccessibilityService.kt` may need updating.

The app does not modify Instagram, inject code into it, or bypass Instagram security. It only uses Android's user-enabled accessibility overlay facility.
